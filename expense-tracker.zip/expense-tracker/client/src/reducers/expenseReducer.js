const initialState = {
    expenses: [],
    loading: true,
  };
  
  export default function (state = initialState, action) {
    switch (action.type) {
      case 'GET_EXPENSES':
        return {
          ...state,
          expenses: action.payload,
          loading: false,
        };
      case 'ADD_EXPENSE':
        return {
          ...state,
          expenses: [...state.expenses, action.payload],
          loading: false,
        };
      case 'UPDATE_EXPENSE':
        return {
          ...state,
          expenses: state.expenses.map((expense) =>
            expense._id === action.payload._id ? action.payload : expense
          ),
          loading: false,
        };
      case 'DELETE_EXPENSE':
        return {
          ...state,
          expenses: state.expenses.filter(
            (expense) => expense._id !== action.payload
          ),
          loading: false,
        };
      default:
        return state;
    }
  }
  