import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { getExpenses, deleteExpense } from '../../actions/expense';

const ExpenseList = () => {
  const dispatch = useDispatch();
  const expenses = useSelector((state) => state.expense.expenses);

  useEffect(() => {
    dispatch(getExpenses());
  }, [dispatch]);

  return (
    <div>
      <h1>Expense List</h1>
      <ul>
        {expenses.map((expense) => (
          <li key={expense._id}>
            {expense.date} - {expense.amount} - {expense.category} - {expense.description}
            <button onClick={() => dispatch(deleteExpense(expense._id))}>Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default ExpenseList;
