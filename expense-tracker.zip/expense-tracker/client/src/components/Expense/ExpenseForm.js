import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { addExpense } from '../../actions/expense';

const ExpenseForm = () => {
  const [formData, setFormData] = useState({
    date: '',
    amount: '',
    category: '',
    description: ''
  });

  const dispatch = useDispatch();

  const { date, amount, category, description } = formData;

  const onChange = (e) => setFormData({ ...formData, [e.target.name]: e.target.value });

  const onSubmit = (e) => {
    e.preventDefault();
    dispatch(addExpense({ date, amount, category, description }));
  };

  return (
    <div>
      <h1>Add Expense</h1>
      <form onSubmit={onSubmit}>
        <input type="date" name="date" value={date} onChange={onChange} required />
        <input type="number" name="amount" value={amount} onChange={onChange} required />
        <input type="text" name="category" value={category} onChange={onChange} required />
        <input type="text" name="description" value={description} onChange={onChange} />
        <button type="submit">Add Expense</button>
      </form>
    </div>
  );
};

export default ExpenseForm;
