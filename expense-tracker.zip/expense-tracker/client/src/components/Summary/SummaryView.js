import React from 'react';
import { useSelector } from 'react-redux';

const SummaryView = () => {
  const expenses = useSelector((state) => state.expense.expenses);

  const totalExpenses = expenses.reduce((total, expense) => total + parseFloat(expense.amount), 0);

  return (
    <div>
      <h1>Summary</h1>
      <p>Total Expenses: {totalExpenses}</p>
      {/* Additional summary information can be added here */}
    </div>
  );
};

export default SummaryView;
