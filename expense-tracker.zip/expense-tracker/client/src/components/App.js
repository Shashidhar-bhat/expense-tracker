import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import Navbar from './Layout/Navbar';
import Login from './Auth/Login';
import Register from './Auth/Register';
import ExpenseForm from './Expense/ExpenseForm';
import ExpenseList from './Expense/ExpenseList';
import CategoryForm from './Category/CategoryForm';
import CategoryList from './Category/CategoryList';
import SummaryView from './Summary/SummaryView';

function App() {
  return (
    <Router>
      <Navbar />
      <Switch>
        <Route exact path="/login" component={Login} />
        <Route exact path="/register" component={Register} />
        <Route exact path="/expenses" component={ExpenseList} />
        <Route exact path="/add-expense" component={ExpenseForm} />
        <Route exact path="/categories" component={CategoryList} />
        <Route exact path="/add-category" component={CategoryForm} />
        <Route exact path="/summary" component={SummaryView} />
      </Switch>
    </Router>
  );
}

export default App;
