import axios from 'axios';

export const getExpenses = () => async (dispatch) => {
  try {
    const res = await axios.get('/api/expenses');

    dispatch({
      type: 'GET_EXPENSES',
      payload: res.data,
    });
  } catch (err) {
    console.error(err);
  }
};

export const addExpense = (expenseData) => async (dispatch) => {
  try {
    const res = await axios.post('/api/expenses', expenseData);

    dispatch({
      type: 'ADD_EXPENSE',
      payload: res.data,
    });
  } catch (err) {
    console.error(err);
  }
};

export const updateExpense = (id, expenseData) => async (dispatch) => {
  try {
    const res = await axios.put(`/api/expenses/${id}`, expenseData);

    dispatch({
      type: 'UPDATE_EXPENSE',
      payload: res.data,
    });
  } catch (err) {
    console.error(err);
  }
};

export const deleteExpense = (id) => async (dispatch) => {
  try {
    await axios.delete(`/api/expenses/${id}`);

    dispatch({
      type: 'DELETE_EXPENSE',
      payload: id,
    });
  } catch (err) {
    console.error(err);
  }
};
