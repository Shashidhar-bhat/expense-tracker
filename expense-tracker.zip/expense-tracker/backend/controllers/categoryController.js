const Category = require('../models/Category');

const addCategory = async (req, res) => {
  const { name } = req.body;

  try {
    const category = new Category({ user: req.user.id, name });
    await category.save();
    res.status(201).json({ message: 'Category added successfully' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

const getCategories = async (req, res) => {
  try {
    const categories = await Category.find({ user: req.user.id });
    res.status(200).json(categories);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

const updateCategory = async (req, res) => {
  const { id } = req.params;
  const { name } = req.body;

  try {
    const category = await Category.findById(id);
    if (!category || category.user.toString() !== req.user.id) {
      return res.status(404).json({ message: 'Category not found' });
    }

    category.name = name;
    await category.save();
    res.status(200).json({ message: 'Category updated successfully' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

const deleteCategory = async (req, res) => {
  const { id } = req.params;

  try {
    const category = await Category.findById(id);
    if (!category || category.user.toString() !== req.user.id) {
      return res.status(404).json({ message: 'Category not found' });
    }

    await category.remove();
    res.status(200).json({ message: 'Category deleted successfully' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

module.exports = { addCategory, getCategories, updateCategory, deleteCategory };
